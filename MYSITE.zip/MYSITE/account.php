<?php
session_start();

$conn = new mysqli('localhost', 'root', '', 'site_data_base');
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="css/account.css">
	
	<title>AdminHub</title>
</head>
<body>






	<!-- CONTENT -->
	<section id="content">

		<!-- MAIN -->
<?php
include 'navsystem.php';
?>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="account.js"></script>
	
</body>
</html>