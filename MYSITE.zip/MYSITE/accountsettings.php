	<?php
		$email=$_SESSION["email"];
		$sql = "SELECT * FROM site_user WHERE email_address = '$email'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$User_Name=$row["User_Name"];
			$Full_Name=$row["fullName"];
			$Phone_Number=$row["phone_number"];
			$pswd=$row["password"];
			$Age=$row["Age"];
			$Gender=$row["Gender"];
			$id=$row["id"];
		}
		}

	/*if ($_SERVER["REQUEST_METHOD"] == "POST") {
		// Obter dados do formulário
		  $email = $_SESSION["email"];
		  $name = $_POST['user_name'];
		  $gender = $_POST['gender'];
		  $fullName = $_POST['full_name'];
		  $age = $_POST['age'];
		  $number = $_POST['phone_number'];
		  $password = $_POST['password'];
		  $passwordRepeat = $_POST["repeat_password"];
		  if($pswd!=$password){
			$passwordHash = password_hash($password, PASSWORD_DEFAULT);
		  }else{$passwordHash = $pswd;}
		  
	  
			$errors = array();
			
			if (empty($name) OR empty($password) OR empty($passwordRepeat)) {
			 array_push($errors,"Os campos User/Name e Password são obrigatórios");
			}
	  
			//https://www.php.net/manual/en/function.filter-var.php
	  
			
			
			
			$sql = "SELECT * FROM site_user WHERE email_address = '$email'";
			$result = mysqli_query($conn, $sql);
			$rowCount = mysqli_num_rows($result);
			if ($rowCount>0) {
			 //array_push($errors,"Email já existente!");
			}
			if (count($errors)>0) {
			 foreach ($errors as  $error) {
				 echo "<div class='alert alert-danger'>$error</div>";
			 }
			}else{
			 
			 $sql = "UPDATE site_user SET User_Name=$name, password=$passwordHash, fullName=$fullName, Gender=$gender, Age=$age, phone_number=$number WHERE email_address = '$email')";
			 $stmt = mysqli_stmt_init($conn);
			 
			if($a==1){
				mysqli_stmt_execute($stmt);
				echo "<div class='alert alert-success'>You are registered successfully.</div>";
				session_start();
				$_SESSION["user"] = "yes";
				header("Location: index.php");	
			}	
			 //die();
			 
			}
			
	  
		// Validar os dados (podes adicionar mais validações)
	  }*/
















if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obter dados do formulário
    $email = $_SESSION["email"];
	$name = $_POST['user_name'];
	$gender = $_POST['gender'];
	$fullName = $_POST['full_name'];
	$age = $_POST['age'];
	$number = $_POST['phone_number'];
	$password = $_POST['password'];
	$passwordRepeat = $_POST["repeat_password"];
	$passwordHash = $pswd;
	if($password==$passwordRepeat){
		if($password!=$pswd){
			$passwordHash = password_hash($password, PASSWORD_DEFAULT);
		}
	}else{
		echo "<div class='alert alert-danger' role='alert'>'The fields for Password and Password/Repeat do not match.'</div>";
	}
    // Validar os dados
    if (empty($name) || empty($password) || empty($passwordRepeat)) {
        echo "<div class='alert alert-danger' role='alert'>'The fields for User/Name and Password are required.'</div>";
    } else {
        // Atualizar registo
        $stmt = $conn->prepare("UPDATE site_user SET User_Name = ?, Age = ?, phone_number = ?, Gender = ?, fullName = ?, password = ? WHERE id = ?");
        $stmt->bind_param("ssssssi", $name, $age, $number, $gender, $fullName, $passwordHash, $id);

        if ($stmt->execute()) {
			echo "<div>'The changes to your accont have been made.'</div>";
        } else {
            echo "Erro: " . $stmt->error;
        }
        $stmt->close();
    }
}
	  ?>
	<link rel="stylesheet" href="css/accountsettings.css">
	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-smile'></i>
			<span class="text">AdminHub</span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="?page=dashboard">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="?page=mystore">
					<i class='bx bxs-shopping-bag-alt' ></i>
					<span class="text">My Store</span>
				</a>
			</li>
			<li>
				<a href="?page=analytics">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">Analytics</span>
				</a>
			</li>
			<li>
				<a href="?page=users">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Users</span>
				</a>
			</li>
			<li>
				<a href="?page=team">
					<i class='bx bxs-group' ></i>
					<span class="text">Team</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li  class="active">
				<a href="?page=account">
					<i class='bx bxs-cog' ></i>
					<span class="text">Account/Settings</span>
				</a>
			</li>
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



<main>
			<div class="head-title">
				<div class="left">
					<h1>Account/Settings</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Account</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="index.php">Home</a>
						</li>
					</ul>
				</div>
			</div>

			<form id="settings-form" method="post" action="">
				<label class="FormLabel">User/Name</label>
                <input type="text" name="user_name" placeholder="User_Name" value = <?php echo $User_Name; ?>>
				<label class="FormLabel">Full/Name</label>
                <input type="text" name="full_name" placeholder="Full_Name" value = <?php echo $Full_Name; ?>>
				<label class="FormLabel">Age</label>
                <input type="number" name="age" placeholder="Age" value = <?php echo $Age; ?>>

				<label class="FormLabel">Gender</label>
				<div class="imput-group">
				<input type="radio" name="gender" id="gender-male" value="Male" <?php if($Gender=="Male"){echo "checked";} ?>>
				<label for="gender-male">Male</label>
        		
        		<input type="radio" name="gender" id="gender-female" value="Female" <?php if($Gender=="Female"){echo "checked";} ?>>
				<label for="gender-female">Female</label>
				</div>
				
				<label class="FormLabel">Phone Number</label>
                <input type="text" name="phone_number" placeholder="Phone_Number" value = <?php echo $Phone_Number; ?>><label class="FormLabel">Password</label>
                <input type="password" name="password" placeholder="Password" value = <?php echo $pswd; ?>>
                <input type="password" name="repeat_password" placeholder="Repeat Password" value = <?php echo $pswd; ?>>
                  <div>
                  </div>
                  <input type="submit" value="Save Changes" >
                </form>
				<br>
				<a href="eliminar.php" class="btn">Delete Account</a>
		</main>