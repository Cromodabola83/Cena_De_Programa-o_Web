<?php
// Conexão à base de dados
session_start();
$conn = new mysqli('localhost', 'root', '', 'site_data_base');
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
        $email=$_SESSION["email"];
		$sql = "SELECT * FROM site_user WHERE email_address = '$email'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$User_Name=$row["User_Name"];
			$Full_Name=$row["fullName"];
			$Phone_Number=$row["phone_number"];
			$pswd=$row["password"];
			$Age=$row["Age"];
			$Gender=$row["Gender"];
			$id=$row["id"];
		}
		}

    // Eliminar registo
    $stmt = $conn->prepare("DELETE FROM site_user WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        session_destroy();
        header('Location: index.php');
        exit();
    } else {
        echo "Erro ao eliminar registo: " . $stmt->error;
    }
    $stmt->close();


$conn->close();
?>