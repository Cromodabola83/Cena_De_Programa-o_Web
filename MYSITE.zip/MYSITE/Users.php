<link rel="stylesheet" href="css/users.css">
	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-smile'></i>
			<span class="text">AdminHub</span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="?page=dashboard">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="?page=mystore">
					<i class='bx bxs-shopping-bag-alt' ></i>
					<span class="text">My Store</span>
				</a>
			</li>
			<li>
				<a href="?page=analytics">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">Analytics</span>
				</a>
			</li>
			<li class="active">
				<a href="?page=users">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Users</span>
				</a>
			</li>
			<li>
				<a href="?page=team">
					<i class='bx bxs-group' ></i>
					<span class="text">Team</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="?page=account">
					<i class='bx bxs-cog' ></i>
					<span class="text">Account/Settings</span>
				</a>
			</li>
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->

<?php

	$sql = "SELECT * FROM site_user";
	$result = $conn->query($sql);
	//echo $_SESSION['email'];
?>
<main>
<div class="head-title">
				<div class="left">
					<h1>Users</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Users</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="index.php">Home</a>
						</li>
					</ul>
				</div>
			</div>
<div class="container">
    <br><br>
    <h1 class="text-decoration-underline text-center text-uppercase">User List</h1>
        <div style="overflow-x:auto;">
            <table class="table align-middle">
            <tr class="table-dark">
                <th>ID</th>
                <th>User_Name</th>
				<th>Real_Name</th>
                <th>Email</th>
                <th>Phone_Number</th>
				<th>Is Admin?</th>
				<th>Age</th>
				<th>Gender</th>
            </tr>
            <tbody class="table-group-divider">
            <?php
                if ($result->num_rows > 0) {
                    while($linha = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $linha['id'] . "</td>";
                        echo "<td>" . $linha['User_Name'] . "</td>";
						echo "<td>" . $linha['fullName'] . "</td>";
                        echo "<td>" . $linha['email_address'] . "</td>";
                        echo "<td>" . $linha['phone_number'] . "</td>";
						if($linha['isAdmin']==0){$isAdmin="False";}else{$isAdmin="True";}
						echo "<td>" . $isAdmin . "</td>";
						echo "<td>" . $linha['Age'] . "</td>";
						echo "<td>" . $linha['Gender'] . "</td>";
                    }
                } else {
                    echo "<tr><td colspan='5'>Nenhum registo encontrado.</td></tr>";
                }
            ?>
            </tbody>
            </table>
        </div>
    </div>
		</main>