-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 19-Nov-2024 às 14:16
-- Versão do servidor: 10.4.32-MariaDB
-- versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `site_data_base`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `site_user`
--

CREATE TABLE `site_user` (
  `id` int(11) NOT NULL,
  `User_Name` varchar(20) NOT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `phone_number` int(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `isdarktheme` tinyint(1) NOT NULL,
  `isAdmin` tinyint(1) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Age` int(11) NOT NULL,
  `fullName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `site_user`
--

INSERT INTO `site_user` (`id`, `User_Name`, `email_address`, `phone_number`, `password`, `isdarktheme`, `isAdmin`, `Gender`, `Age`, `fullName`) VALUES
(24, 'a', 'alexandremesilva12@gmail.com', 111111, '$2y$10$ysxTY44A4pCVLlg0u8.3Y.POKIZn.yvAdIN7ZMj..d3V/kXz5yS8q', 0, 0, 'Male', 111, 'Alexandre Miguel Elias da Silva'),
(25, 'Alex', 'a10671@csmiguel.pt', NULL, '$2y$10$2U.aHlhp6j7cLuWIFgZH0OR5mqsUONMOU7ro4tGNmjT8KSr9HEZBG', 0, 0, '', 0, '');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `site_user`
--
ALTER TABLE `site_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `site_user`
--
ALTER TABLE `site_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
